All images comes from https://unsplash.com/

They provided as an example User wallpapers directory for Colorizer

Feel free to change user_wallpapers_dir in Colorizer configuration (Colorizer -> Settings -> Wallpapers directories -> Edit...)
